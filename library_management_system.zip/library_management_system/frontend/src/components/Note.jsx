import React from "react";
// import "../styles/Note.css"

function Note({ note, onDelete }) {
    const formattedDate = new Date(note.created_at).toLocaleDateString("en-US")

    return (
        <div className="note-container" style={{border: '5px solid black', backgroundColor:' #82c4d4', padding: '10px', margin: '10px'}}>
        <img src={note.image} alt={note.file} style={{width:'200px'}}/>

    <p className="note-title">TITLE: {note.title}</p>
    <p className="note-title">AUTHOR: {note.author}</p>
    <p className="note-date">Published on:{note.publish_year}</p>
    <button className="delete-button" onClick={() => onDelete(note.id)}>
        Delete
    </button>
</div>

    );

//     return(
//         <table className="note-table">
//     <thead>
//         <tr>
//             <th>Title</th>
//             <th>Download</th>
//             <th>Date</th>
//             <th>ID</th>
//             <th>Action</th>
//         </tr>
//     </thead>
//     <tbody>
//         <tr>
//             <td>{note.title}</td>
//             <td><a href={note.file}>Download</a></td>
//             <td>{formattedDate}</td>
//             <td>{note.id}</td>
//             <td><button onClick={() => onDelete(note.id)}>Delete</button></td>
//         </tr>
//     </tbody>
// </table>

//     );
}

export default Note