function Notfound() {
    return <div>
        <center>
            <h1>page not found</h1>
        </center>
    </div>

}

export default Notfound